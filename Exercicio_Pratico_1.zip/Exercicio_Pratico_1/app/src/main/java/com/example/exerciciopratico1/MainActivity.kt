package com.example.exerciciopratico1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView


class MainActivity : AppCompatActivity() {

    private lateinit var nomeTextView: TextView
    private lateinit var messageTextView: TextView
    private lateinit var button: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        nomeTextView = findViewById(R.id.nome)
        messageTextView = findViewById(R.id.message)
        button = findViewById(R.id.button)

        button.setOnClickListener {
            val mensagem = "Olá ${nomeTextView.text}\nSeja bem-vindo!"
            messageTextView.text = mensagem
        }
    }
}

/*

    Use val para uma variável cujo valor nunca muda.
    Não é possível reatribuir um valor a uma variável que tenha sido declarada usando val.
    Use var para uma variável cujo valor possa ser mudado.


    lateinit permite que você evite inicializar uma propriedade quando um objeto for construído.
    Se a propriedade for referenciada antes de ser inicializada, o Kotlin emitirá um UninitializedPropertyAccessException.
    Portanto, inicialize a propriedade assim que possível.

*/